<footer class="footer p-5 ">
    <div class="row align-items-center text-center">
        <div class="col-lg-12 mb-lg-0 mb-4 text-center">
           
                Copyright
                ©
                {{ date('Y') }}
                <p class="text-sm opacity-6">Malapascua Room Reservation</p>
                <p class="text-xs">Developed by: Marjurie Villanueva</p>
        </div>
        
    </div>
</footer>
