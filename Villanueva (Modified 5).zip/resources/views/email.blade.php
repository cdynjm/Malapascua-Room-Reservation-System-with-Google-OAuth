<x-guest-layout>

{!! $body !!}

</x-guest-layout>