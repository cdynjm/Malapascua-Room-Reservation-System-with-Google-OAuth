$.ajaxSetup({
    headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
    headers: {  "Authorization": "Bearer " + $('meta[name="token"]').attr('content') }
});

$(document).on('click', "#add-room", function() {
    $("#createRoomModal").modal('show');
});

var SweetAlert = Swal.mixin({
    customClass: {
        confirmButton: 'btn btn-primary',
        cancelButton: 'btn btn-secondary ms-3'
    },
    buttonsStyling: false
});

$(document).on('submit', "#create-room", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/create/room',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            SweetAlert.fire({
                position: 'center',
                icon: 'info',
                title: 'Processing...',
                allowOutsideClick: true,
                showConfirmButton: false
            });
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $("#rooms-data-result").html(response.Rooms);
                $("#createRoomModal").modal('hide');
                $('input').val();
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                });
            }
        }
    })
});

$(document).on('click', "#edit-room", function() {
    var id = $(this).data('room-id');
    var room = $(this).closest('.card').find('.get-room').text();
    var description = $(this).closest('.card').find('.get-description').text();
    var price = $(this).closest('.card').find('.get-price').val();
    var maxguest = $(this).closest('.card').find('.get-guest').text();

    $("#edit-room-id").val(id);
    $("#edit-room-name").val(room);
    $("#edit-description").val(description);
    $("#edit-price").val(price);
    $("#edit-maxguest").val(maxguest);
    $("#editRoomModal").modal('show');
});

$(document).on('submit', "#update-room", function(e){
    e.preventDefault();
    const formData = new FormData(this);
    formData.append('_method', 'PUT');
    $.ajax({
        type: 'POST',
        url: '/update/room',
        data: formData,
        dataType: 'json',
        contentType: false,
        cache: false,
        processData: false,
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        beforeSend: function(){
            SweetAlert.fire({
                position: 'center',
                icon: 'info',
                title: 'Processing...',
                allowOutsideClick: true,
                showConfirmButton: false
            });
        },
        success: function(response){
            if(response.Error == 0) {
                $("#rooms-data-result").html(response.Rooms);
                $("#editRoomModal").modal('hide');
                $('input').val();
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                });
            }
        }
    });
});


$(document).on("click", "#delete-room", function(e){
    var id = $  (this).data('room-id');
    SweetAlert.fire({
        icon: 'warning',
        title: 'Are you sure?',
        text: "This will delete the room permanently.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Delete it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'DELETE',
                url: '/delete/room',
                data: {id},
                dataType: 'json',
                cache: false,
                headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                beforeSend:function(){
                    SweetAlert.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Deleting...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if(response.Error == 0) {
                        $("#rooms-data-result").html(response.Rooms);
                        $('input').val();
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        }).then(function(){ 
                            location.reload();
                            });
                    }
                }
            });
        }
    })
});

$(document).on("click", "#cancel-reservation", function(e){
    var id = $  (this).data('id');
    SweetAlert.fire({
        icon: 'warning',
        title: 'Are you sure?',
        text: "This will cancel the reservation.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Cancel it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'DELETE',
                url: '/delete/client-reservation',
                data: {id},
                dataType: 'json',
                cache: false,
                headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                beforeSend:function(){
                    SweetAlert.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Cancelling...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if(response.Error == 0) {
                        $("#pending-reservations-data-result").html(response.Reservations);
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        })
                    }
                }
            });
        }
    })
});

$(document).on("click", "#approved-reservation", function(e){
    var id = $  (this).data('id');
    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will approved the reservation.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Reserve it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/update/approved-reservation',
                data: {
                    _method: 'PATCH',
                    id:id
                },
                dataType: 'json',
                cache: false,
                headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                beforeSend:function(){
                    SweetAlert.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Processing...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if(response.Error == 0) {
                        $("#pending-reservations-data-result").html(response.Reservations);
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        });
                    }
                }
            });
        }
    })
});

$(document).on("click", "#finish-reservation", function(e){
    var id = $  (this).data('id');
    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will finish the transaction.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Finish it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/update/finish-reservation',
                data: {
                    _method: 'PATCH',
                    id:id
                },
                dataType: 'json',
                cache: false,
                headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                beforeSend:function(){
                    SweetAlert.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Processing...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if(response.Error == 0) {
                        $("#approved-reservations-data-result").html(response.Reservations);
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        });
                    }
                }
            });
        }
    })
});

$(document).on("click", "#check-in-time", function(e){
    var id = $  (this).data('id');
    SweetAlert.fire({
        icon: 'warning',
        title: 'Are you sure?',
        text: "This will check this customer in",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Check In!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/update/check-in',
                data: {
                    _method: 'PATCH',
                    id:id
                },
                dataType: 'json',
                cache: false,
                headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                beforeSend:function(){
                    SweetAlert.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Checking In...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if(response.Error == 0) {
                        $("#approved-reservations-data-result").html(response.Reservations);
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        })
                    }
                }
            });
        }
    })
});

$(document).on("click", "#check-out-time", function(e){
    var id = $  (this).data('id');
    SweetAlert.fire({
        icon: 'warning',
        title: 'Are you sure?',
        text: "This will check this customer out",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Check Out!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/update/check-out',
                data: {
                    _method: 'PATCH',
                    id:id
                },
                dataType: 'json',
                cache: false,
                headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                beforeSend:function(){
                    SweetAlert.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Checking Out...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if(response.Error == 0) {
                        $("#approved-reservations-data-result").html(response.Reservations);
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        })
                    }
                }
            });
        }
    })
});