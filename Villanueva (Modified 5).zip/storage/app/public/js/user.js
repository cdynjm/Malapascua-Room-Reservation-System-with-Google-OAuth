$.ajaxSetup({
    headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
    headers: {  "Authorization": "Bearer " + $('meta[name="token"]').attr('content') }
});

var SweetAlert = Swal.mixin({
    customClass: {
        confirmButton: 'btn btn-primary',
        cancelButton: 'btn btn-secondary ms-3'
    },
    buttonsStyling: false
});

$(document).on('click', "#add-to-cart", function() {
    var id = $(this).data('room-id');
    var room = $(this).closest('.card').find('.get-room').text();
    var price = $(this).closest('.card').find('.get-price').val();

    $("#reserve-id").val(id);
    $("#reserve-room").val(room);
    $("#reserve-price").val(price);

    $("#createCartModal").modal('show');
});

$(document).on('change', "#checkout", function() {

    var checkin = new Date($("#checkin").val());
    var checkout = new Date($("#checkout").val());
    var price = $("#reserve-price").val();

    var difference = checkout - checkin;
    var daysDifference = difference / (1000 * 60 * 60 * 24);

    if(daysDifference >= 0) {
        $("#days").val(daysDifference);
        $("#total-payment").val(price * daysDifference);
    }
    else {
        $("#days").val(0);
        $("#total-payment").val(0);
    }

});

$(document).on('change', "#checkin", function() {

    var checkin = new Date($("#checkin").val());
    var checkout = new Date($("#checkout").val());
    var price = $("#reserve-price").val();

    var difference = checkout - checkin;
    var daysDifference = difference / (1000 * 60 * 60 * 24);

    if(daysDifference >= 0) {
        $("#days").val(daysDifference);
        $("#total-payment").val(price * daysDifference);
    }
    else {
        $("#days").val(0);
        $("#total-payment").val(0);
    }

});

$(document).ready(function () {
    $('#createCartModal').on('hidden.bs.modal', function () {
        $('#checkin-room input').val('');
    });
});

$(document).on("submit", "#checkin-room", function(e){
    e.preventDefault();

    var checkin = $("#checkin").val();
    var checkout = $("#checkout").val();
    var days = $("#days").val();
    var total_payment = $("#total-payment").val();

    if(checkin !='' && checkout != '' && total_payment != 0 && days != 0) {

        SweetAlert.fire({
            icon: 'question',
            title: 'Are you sure?',
            text: "Confirm your reservation.",
            showCancelButton: true,
            confirmButtonColor: '#160e45',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Confirm it!'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    type: 'POST',
                    url: '/create/reservation',
                    data: new FormData(this),
                    dataType: 'json',
                    contentType: false,
                    cache: false,
                    processData:false,
                    headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    beforeSend:function(){
                        SweetAlert.fire({
                            position: 'center',
                            icon: 'info',
                            title: 'Processing...',
                            showConfirmButton: false
                        })
                    },
                    success:function(response){
                        if(response.Error == 0) {
                            $("#dashboard-data-result").html(response.Dashboard);
                            $("#createCartModal").modal('hide');
                            $('input[type=date]').val('');
                            $('input[name=days]').val('');
                            $('input[name=total_payment]').val('');
                            SweetAlert.fire({
                                icon: 'success',
                                title: 'Done',
                                text: response.Message,
                                confirmButtonColor: "#3a57e8"
                            });
                        }
                        if(response.Error == 1) {
                            SweetAlert.fire({
                                icon: 'error',
                                title: 'Days Unavailable',
                                text: response.Message,
                                confirmButtonColor: "#3a57e8"
                            });
                        }
                    }
                });
            }
        })
    }

    else {
        SweetAlert.fire({
            icon: 'error',
            title: 'Empty Field(s)',
            text: 'Please do not leave fields empty or zero',
            confirmButtonColor: "#3a57e8"
        })
    }
});

$(document).on("click", "#cancel-reservation", function(e){
    var id = $  (this).data('id');
    SweetAlert.fire({
        icon: 'warning',
        title: 'Are you sure?',
        text: "This will cancel the reservation.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Cancel it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'DELETE',
                url: '/delete/reservation',
                data: {id},
                dataType: 'json',
                cache: false,
                headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                beforeSend:function(){
                    SweetAlert.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Cancelling...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if(response.Error == 0) {
                        $("#myreservations-data-result").html(response.MyReservations);
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        });
                    }
                }
            });
        }
    })
});

$(document).on("submit", "#pay-online", function(e){
    e.preventDefault();
    SweetAlert.fire({
        icon: 'warning',
        title: 'Are you sure?',
        text: "This will deduct the balance on your account.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Pay!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/pay-online',
                data: new FormData(this),
                dataType: 'json',
                contentType: false,
                cache: false,
                processData:false,
                headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                beforeSend:function(){
                    SweetAlert.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Processing...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if(response.Error == 0) {
                        window.location.href = response.Path;
                    }
                }
            });
        }
    })
});

$(document).on('keyup', "#search-room", function(e){
    var room = $("#search-room").val();
    $.ajax({
        type: 'POST',
        url: '/search/room',
        data: {room},
        dataType: 'json',
        cache: false,
        headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
        success: function(response)
        {
            if(response.Error == 0) {
                $("#dashboard-data-result").html(response.Dashboard);
            }
        }
    })
});