var SweetAlert = Swal.mixin({
    customClass: {
        confirmButton: 'btn btn-primary',
        cancelButton: 'btn btn-secondary ms-3'
    },
    buttonsStyling: false
});

$(document).on('submit', "#sign-in", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/sign-in',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            SweetAlert.fire({
                position: 'center',
                icon: 'info',
                title: 'Signing In...',
                allowOutsideClick: true,
                showConfirmButton: false
            });
        },
        success: function(response)
        {
            if(response.Error == 1) {
                SweetAlert.close();
                $("#error").show(50);
                $("#error").text(response.Message);
            }
            if(response.Error == 0) {
                location.reload();
            }
        }
    })
});