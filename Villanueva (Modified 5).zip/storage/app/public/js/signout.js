$(document).on('submit', "#sign-out", function(e){
    e.preventDefault();
    Swal.fire({
        position: 'center',
        icon: 'info',
        title: 'Signing Out...',
        allowOutsideClick: false,
        showConfirmButton: false
    });
    const formData = new FormData(this);
    $.ajax({
        url: '/logout',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(response){
            location.reload();
        },
        error: function(error){
            console.error('Error:', error);
        }
    });
});
