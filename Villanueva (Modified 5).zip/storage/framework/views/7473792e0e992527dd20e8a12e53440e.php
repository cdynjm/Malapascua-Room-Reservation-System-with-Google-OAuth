<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Documents\Web Projects\Laravel Framework\On Going Projects\Villanueva\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>