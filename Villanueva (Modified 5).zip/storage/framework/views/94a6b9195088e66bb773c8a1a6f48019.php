<?php
    use Illuminate\Support\Str;
    use App\Http\Controllers\AESCipher;
    $aes = new AESCipher();
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
        <?php echo $__env->make('components.app.navbar', ['title' => 'History'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container-fluid py-4 px-5">
            <div class="row">
                <?php
                    $cnt = 0;
                ?>
                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <img src="<?php echo e(asset('storage/rooms/'.$res->Rooms->picture)); ?>" class="img-fluid rounded-start" alt="...">
                                  </div>
                                  <div class="col-md-8">
                                    <h5 class="card-title"><?php echo e($res->Rooms->room); ?></h5>
                                    <p class="card-text"><?php echo e($res->Rooms->description); ?></p>                                    
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p>Price: <span class='fw-bold text-primary'>₱ <?php echo e(number_format($res->Rooms->price, 2)); ?> per day</span></p>
                                            <span class="card-title"><small class="text-muted"><i>Amount: </i></small>
                                                <span class="fw-bolder">₱ <?php echo e(number_format($res->total_payment, 2)); ?></span>
                                            </span>

                                            <div class="fw-bold">
                                                <i class="fas fa-calendar-check text-success me-1"></i>
                                                <?php echo e(date('M d, Y', strtotime($res->checkin))); ?> -
                                                <?php echo e(date('M d, Y', strtotime($res->checkout))); ?> |
                                                <?php echo e($res->days); ?> day/s
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-2">
                                                <p class="text-sm my-0">In: 
                                                    <?php if($res->time_in != null): ?>
                                                        <span class="text-sm fw-bolder"><?php echo e(date('M d, Y | h:i A', strtotime($res->time_in))); ?></span>
                                                    <?php else: ?>
                                                        <span class="text-danger">--</span>
                                                    <?php endif; ?>
                                                </p>
                                                <p class="text-sm my-0">Out: 
                                                    <?php if($res->time_out != null): ?>
                                                        <span class="text-sm fw-bolder"><?php echo e(date('M d, Y | h:i A', strtotime($res->time_out))); ?></span>
                                                    <?php else: ?>
                                                        <span class="text-danger">--</span>
                                                    <?php endif; ?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    

                                    <hr>
                                        <?php if($res->payment_method != null): ?>
                                            <p class="text-sm mb-0 text-success">Paid Online</p>

                                            <a wire:navigate href=
                                            "
                                            <?php if($res->payment_method == 1): ?>
                                                <?php echo e(route('gcash', ['id' => $aes->encrypt($res->id), 'key' => \Str::random(50)])); ?>

                                            <?php endif; ?>
                                            <?php if($res->payment_method == 2): ?>
                                                <?php echo e(route('paymaya', ['id' => $aes->encrypt($res->id), 'key' => \Str::random(50)])); ?>

                                            <?php endif; ?>
                                            " class="text-sm text-dark text-decoration-underline">View Receipt</a>
                                        <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    $cnt = 1;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($cnt == 0): ?>
                <div class="col-md-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <p class="mt-3">No Data Found</p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>
    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Documents\Web Projects\Laravel Framework\Final Projects\Villanueva\resources\views/users/history.blade.php ENDPATH**/ ?>