<footer class="footer p-5 ">
    <div class="row align-items-center text-center">
        <div class="col-lg-12 mb-lg-0 mb-4 text-center">
           
                Copyright
                ©
                <script>
                    document.write(new Date().getFullYear())
                </script>
                <p class="text-sm opacity-6">Malapascua Room Reservation</p>
                <p class="text-xs">Developed by: Marjurie Villanueva</p>
        </div>
        
    </div>
</footer>
<?php /**PATH D:\Documents\Web Projects\Laravel Framework\On Going Projects\Villanueva\resources\views/components/app/footer.blade.php ENDPATH**/ ?>