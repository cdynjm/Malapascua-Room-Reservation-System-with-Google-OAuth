<?php echo e($slot); ?>

<?php /**PATH D:\Documents\Web Projects\Laravel Framework\Final Projects\Villanueva\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>