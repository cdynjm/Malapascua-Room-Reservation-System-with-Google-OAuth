<?php echo e($slot); ?>

<?php /**PATH D:\Documents\Web Projects\Laravel Framework\On Going Projects\Villanueva\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>